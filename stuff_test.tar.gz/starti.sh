#!/bin/bash
[ "root" != "$USER" ] && exec sudo ./initgpio.sh
