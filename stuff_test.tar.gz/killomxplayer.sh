#!/bin/bash
kill `pidof "/usr/bin/omxplayer.bin"`