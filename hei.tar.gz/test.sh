#/bin/bash
minuten=200
gnuplot -p -e "set datafile separator ';'; set style line 101 lw 5 lt rgb '#09000f'; set style line 102 lw 5 lt rgb '#1234f6'; set style line 103 lw 5 lt rgb '#72bfaa'; set yrange [10:100]; set terminal wxt size 1000,800 position 280,224 font ',14'; plot '< tail -$minuten tempwerte.txt | cut -c 5-' using 1:5 title 'BoilerOben' with lines ls 101, '' using 1:6 title 'BoilerUnten' with lines ls 102, '' using 1:12 title 'PufferOben' with lines ls 103" &

sleep 5
kill $!

#kill `cat boiler_warn_proc`